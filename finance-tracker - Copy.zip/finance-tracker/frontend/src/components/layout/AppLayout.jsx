import React, { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { LayoutDashboard, User, LogOut, Menu, X, TrendingUp } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import toast from 'react-hot-toast';

export default function AppLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out successfully');
    navigate('/signin');
  };

  const initials = user?.username?.slice(0, 2).toUpperCase() || 'FT';

  const SidebarContent = () => (
    <>
      <div className="sidebar-logo">
        <div className="sidebar-logo-icon">💰</div>
        <span className="sidebar-logo-text">FinTrack</span>
      </div>

      <nav className="sidebar-nav">
        <span className="sidebar-section-title">Navigation</span>
        <NavLink
          to="/"
          end
          className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
          onClick={() => setMobileOpen(false)}
        >
          <LayoutDashboard size={17} />
          Dashboard
        </NavLink>
        <NavLink
          to="/profile"
          className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
          onClick={() => setMobileOpen(false)}
        >
          <User size={17} />
          Profile
        </NavLink>
      </nav>

      <div className="sidebar-footer">
        <div className="sidebar-user">
          <div className="sidebar-avatar">{initials}</div>
          <div style={{ minWidth: 0 }}>
            <div className="sidebar-username">{user?.username}</div>
            <div className="sidebar-email">{user?.email}</div>
          </div>
        </div>
        <button className="sidebar-link btn-ghost" onClick={handleLogout} style={{ color: '#ff4d6d', marginTop: 4 }}>
          <LogOut size={16} />
          Sign out
        </button>
      </div>
    </>
  );

  return (
    <div className="app-container">
      {/* Desktop sidebar */}
      <aside className="sidebar">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar overlay */}
      {mobileOpen && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 199, background: 'rgba(0,0,0,0.6)' }} onClick={() => setMobileOpen(false)} />
      )}
      <aside className={`sidebar${mobileOpen ? ' mobile-open' : ''}`} style={{ display: mobileOpen ? 'flex' : undefined }}>
        <SidebarContent />
      </aside>

      <div className="main-content">
        {/* Mobile header */}
        <header className="mobile-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div className="sidebar-logo-icon" style={{ width: 28, height: 28, fontSize: 14, borderRadius: 6 }}>💰</div>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>FinTrack</span>
          </div>
          <button className="btn btn-ghost btn-icon" onClick={() => setMobileOpen(true)}>
            <Menu size={20} />
          </button>
        </header>

        <main className="page-content fade-in">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
