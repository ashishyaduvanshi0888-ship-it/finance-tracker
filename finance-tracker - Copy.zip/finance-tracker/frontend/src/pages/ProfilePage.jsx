import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { User, Mail, Lock, LogOut, Edit2, Check, X, Eye, EyeOff, Shield } from 'lucide-react';
import { userAPI } from '../api';
import { useAuth } from '../context/AuthContext';
import OTPInput from '../components/ui/OTPInput';
import { format } from 'date-fns';

export default function ProfilePage() {
  const { user, logout, refreshUser } = useAuth();
  const navigate = useNavigate();

  const [editingUsername, setEditingUsername] = useState(false);
  const [newUsername, setNewUsername] = useState(user?.username || '');
  const [savingUsername, setSavingUsername] = useState(false);

  // Change password flow: 'idle' | 'otp' | 'form'
  const [cpStep, setCpStep] = useState('idle');
  const [cpLoading, setCpLoading] = useState(false);
  const [otp, setOtp] = useState('');
  const [cpForm, setCpForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [showPassFields, setShowPassFields] = useState({ current: false, new: false });

  const handleSaveUsername = async () => {
    if (!newUsername.match(/^[a-zA-Z0-9_]{3,30}$/)) {
      return toast.error('Username: 3-30 characters, letters/numbers/underscore only');
    }
    setSavingUsername(true);
    try {
      await userAPI.updateProfile({ username: newUsername });
      await refreshUser();
      toast.success('Username updated!');
      setEditingUsername(false);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setSavingUsername(false);
    }
  };

  const handleRequestOTP = async () => {
    setCpLoading(true);
    try {
      await userAPI.requestChangePassword();
      setCpStep('otp');
      setOtp('');
      toast.success('OTP sent to your email');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send OTP');
    } finally {
      setCpLoading(false);
    }
  };

  const handleVerifyOTPForPassword = () => {
    if (otp.length !== 6) return toast.error('Enter the 6-digit OTP');
    setCpStep('form');
  };

  const handleChangePassword = async (e) => {
    e.preventDefault();
    const { currentPassword, newPassword, confirmPassword } = cpForm;
    if (!currentPassword) return toast.error('Enter current password');
    if (newPassword.length < 8 || !/\d/.test(newPassword)) return toast.error('New password: min 8 chars with a number');
    if (newPassword !== confirmPassword) return toast.error('Passwords do not match');

    setCpLoading(true);
    try {
      await userAPI.changePassword({ otp, currentPassword, newPassword });
      toast.success('Password changed successfully!');
      setCpStep('idle');
      setOtp('');
      setCpForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Change password failed');
      if (err.response?.data?.message?.includes('OTP')) {
        setCpStep('otp');
        setOtp('');
      }
    } finally {
      setCpLoading(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    toast.success('Logged out');
    navigate('/signin');
  };

  return (
    <div className="fade-in">
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, letterSpacing: '-0.5px' }}>Profile</h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: 4, fontSize: 14 }}>Manage your account information</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20, maxWidth: 900 }}>

        {/* Account Info */}
        <div className="card card-padded" style={{ gridColumn: 'span 2' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 28 }}>
            <div style={{
              width: 64, height: 64, borderRadius: '50%',
              background: 'linear-gradient(135deg, var(--accent-green), var(--accent-blue))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontSize: 26, fontWeight: 700, color: '#040a06',
              flexShrink: 0,
            }}>
              {user?.username?.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700 }}>{user?.username}</div>
              <div style={{ color: 'var(--text-secondary)', fontSize: 14 }}>{user?.email}</div>
              {user?.isVerified && (
                <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4, background: 'var(--accent-green-dim)', color: 'var(--accent-green)', padding: '2px 10px', borderRadius: 999, fontSize: 11, fontWeight: 600, marginTop: 4 }}>
                  <Shield size={11} /> Verified
                </div>
              )}
            </div>
          </div>

          {/* Fields */}
          <div>
            {/* Username */}
            <div className="profile-field">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div className="profile-field-label"><User size={11} style={{ verticalAlign: 'middle', marginRight: 4 }} />Username</div>
                {!editingUsername && (
                  <button className="btn btn-ghost btn-sm" onClick={() => { setEditingUsername(true); setNewUsername(user?.username); }}>
                    <Edit2 size={13} /> Edit
                  </button>
                )}
              </div>
              {editingUsername ? (
                <div style={{ display: 'flex', gap: 8, marginTop: 6 }}>
                  <input className="form-input" value={newUsername} onChange={(e) => setNewUsername(e.target.value)} style={{ flex: 1 }} autoFocus />
                  <button className="btn btn-primary btn-sm" onClick={handleSaveUsername} disabled={savingUsername}>
                    {savingUsername ? <div className="spinner spinner-sm" /> : <Check size={14} />}
                  </button>
                  <button className="btn btn-secondary btn-sm" onClick={() => setEditingUsername(false)}><X size={14} /></button>
                </div>
              ) : (
                <div className="profile-field-value">{user?.username}</div>
              )}
            </div>

            {/* Email */}
            <div className="profile-field">
              <div className="profile-field-label"><Mail size={11} style={{ verticalAlign: 'middle', marginRight: 4 }} />Email</div>
              <div className="profile-field-value">{user?.email}</div>
            </div>

            {/* Password */}
            <div className="profile-field">
              <div className="profile-field-label"><Lock size={11} style={{ verticalAlign: 'middle', marginRight: 4 }} />Password</div>
              <div className="profile-field-value" style={{ letterSpacing: 4 }}>••••••••</div>
            </div>

            {/* Member since */}
            <div className="profile-field">
              <div className="profile-field-label">Member Since</div>
              <div className="profile-field-value">{user?.createdAt ? format(new Date(user.createdAt), 'dd MMMM yyyy') : '—'}</div>
            </div>

            {user?.lastLogin && (
              <div className="profile-field">
                <div className="profile-field-label">Last Login</div>
                <div className="profile-field-value">{format(new Date(user.lastLogin), 'dd MMM yyyy, h:mm a')}</div>
              </div>
            )}
          </div>
        </div>

        {/* Change Password */}
        <div className="card card-padded">
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 8 }}>
            <Lock size={16} color="var(--accent-green)" /> Change Password
          </h3>

          {cpStep === 'idle' && (
            <>
              <p style={{ color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.6, marginBottom: 16 }}>
                An OTP will be sent to your email <strong style={{ color: 'var(--text-primary)' }}>{user?.email}</strong> to verify the change.
              </p>
              <button className="btn btn-secondary btn-full" onClick={handleRequestOTP} disabled={cpLoading}>
                {cpLoading ? <><div className="spinner spinner-sm" /> Sending OTP...</> : <><Shield size={15} /> Request OTP</>}
              </button>
            </>
          )}

          {cpStep === 'otp' && (
            <div>
              <p style={{ color: 'var(--text-secondary)', fontSize: 13, marginBottom: 20 }}>
                Enter the 6-digit OTP sent to your email
              </p>
              <OTPInput value={otp} onChange={setOtp} />
              <div style={{ display: 'flex', gap: 8, marginTop: 20 }}>
                <button className="btn btn-primary btn-full" onClick={handleVerifyOTPForPassword} disabled={otp.length !== 6}>
                  Verify OTP
                </button>
                <button className="btn btn-secondary" onClick={() => setCpStep('idle')}>Cancel</button>
              </div>
            </div>
          )}

          {cpStep === 'form' && (
            <form onSubmit={handleChangePassword}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                <div className="form-group">
                  <label className="form-label">Current Password</label>
                  <div style={{ position: 'relative' }}>
                    <input
                      type={showPassFields.current ? 'text' : 'password'}
                      className="form-input" placeholder="Your current password"
                      value={cpForm.currentPassword}
                      onChange={(e) => setCpForm({ ...cpForm, currentPassword: e.target.value })}
                      style={{ paddingRight: 44 }} autoFocus
                    />
                    <button type="button" className="btn btn-ghost btn-icon"
                      onClick={() => setShowPassFields({ ...showPassFields, current: !showPassFields.current })}
                      style={{ position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)', padding: '4px 8px' }}>
                      {showPassFields.current ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">New Password</label>
                  <div style={{ position: 'relative' }}>
                    <input
                      type={showPassFields.new ? 'text' : 'password'}
                      className="form-input" placeholder="Min 8 chars with a number"
                      value={cpForm.newPassword}
                      onChange={(e) => setCpForm({ ...cpForm, newPassword: e.target.value })}
                      style={{ paddingRight: 44 }}
                    />
                    <button type="button" className="btn btn-ghost btn-icon"
                      onClick={() => setShowPassFields({ ...showPassFields, new: !showPassFields.new })}
                      style={{ position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)', padding: '4px 8px' }}>
                      {showPassFields.new ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                </div>
                <div className="form-group">
                  <label className="form-label">Confirm New Password</label>
                  <input type="password" className="form-input" placeholder="Repeat new password"
                    value={cpForm.confirmPassword}
                    onChange={(e) => setCpForm({ ...cpForm, confirmPassword: e.target.value })} />
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <button type="submit" className="btn btn-primary btn-full" disabled={cpLoading}>
                    {cpLoading ? <><div className="spinner spinner-sm" /> Changing...</> : 'Change Password'}
                  </button>
                  <button type="button" className="btn btn-secondary" onClick={() => setCpStep('idle')}>Cancel</button>
                </div>
              </div>
            </form>
          )}
        </div>

        {/* Danger zone */}
        <div className="card card-padded" style={{ borderColor: 'rgba(255, 77, 109, 0.2)' }}>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 16, fontWeight: 700, marginBottom: 12, color: 'var(--accent-red)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <LogOut size={16} /> Sign Out
          </h3>
          <p style={{ color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.6, marginBottom: 16 }}>
            You'll be signed out of your account on this device.
          </p>
          <button className="btn btn-danger btn-full" onClick={handleLogout}>
            <LogOut size={15} /> Sign Out
          </button>
        </div>
      </div>
    </div>
  );
}
