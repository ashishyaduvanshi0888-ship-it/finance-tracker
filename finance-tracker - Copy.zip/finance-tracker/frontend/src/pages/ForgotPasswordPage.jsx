import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { ArrowLeft, Eye, EyeOff, CheckCircle } from 'lucide-react';
import { authAPI } from '../api';
import OTPInput from '../components/ui/OTPInput';

export default function ForgotPasswordPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState('email'); // 'email' | 'otp' | 'reset' | 'done'
  const [email, setEmail] = useState('');
  const [userId, setUserId] = useState('');
  const [otp, setOtp] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    if (!email) return toast.error('Enter your email');
    setLoading(true);
    try {
      const { data } = await authAPI.forgotPassword({ email });
      if (data.data.userId) setUserId(data.data.userId);
      setStep('otp');
      toast.success('OTP sent! Check your email.');
    } catch {
      toast.error('Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) return toast.error('Enter the 6-digit OTP');
    setLoading(true);
    try {
      const { data } = await authAPI.verifyForgotOTP({ userId, otp });
      setResetToken(data.data.resetToken);
      setStep('reset');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid OTP');
      setOtp('');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e) => {
    e.preventDefault();
    if (newPassword.length < 8 || !/\d/.test(newPassword)) {
      return toast.error('Password must be at least 8 chars with a number');
    }
    if (newPassword !== confirmPassword) return toast.error('Passwords do not match');
    setLoading(true);
    try {
      await authAPI.resetPassword({ resetToken, newPassword });
      setStep('done');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Reset failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="auth-logo-icon">💰</div>
          <span className="auth-logo-text">FinTrack</span>
        </div>

        {/* Step: Email */}
        {step === 'email' && (
          <>
            <h1 className="auth-title">Forgot password?</h1>
            <p className="auth-subtitle">Enter your email and we'll send a reset OTP</p>
            <form className="auth-form" onSubmit={handleEmailSubmit}>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input
                  type="email" className="form-input" placeholder="you@example.com"
                  value={email} onChange={(e) => setEmail(e.target.value)} autoFocus
                />
              </div>
              <button type="submit" className="btn btn-primary btn-lg btn-full" disabled={loading}>
                {loading ? <><div className="spinner spinner-sm" /> Sending...</> : 'Send OTP'}
              </button>
            </form>
            <div className="auth-footer"><Link to="/signin"><ArrowLeft size={13} style={{ verticalAlign: 'middle', marginRight: 4 }} />Back to sign in</Link></div>
          </>
        )}

        {/* Step: OTP */}
        {step === 'otp' && (
          <>
            <button className="btn btn-ghost btn-sm" style={{ marginBottom: 20, padding: '6px 0' }} onClick={() => setStep('email')}>
              <ArrowLeft size={15} /> Back
            </button>
            <h1 className="auth-title">Enter OTP</h1>
            <p className="auth-subtitle">We sent a 6-digit code to <strong style={{ color: 'var(--text-primary)' }}>{email}</strong></p>
            <div style={{ margin: '28px 0' }}>
              <OTPInput value={otp} onChange={setOtp} />
            </div>
            <button className="btn btn-primary btn-lg btn-full" onClick={handleVerifyOTP} disabled={loading || otp.length !== 6}>
              {loading ? <><div className="spinner spinner-sm" /> Verifying...</> : 'Verify OTP'}
            </button>
          </>
        )}

        {/* Step: Reset */}
        {step === 'reset' && (
          <>
            <h1 className="auth-title">Set new password</h1>
            <p className="auth-subtitle">Create a strong password for your account</p>
            <form className="auth-form" onSubmit={handleReset}>
              <div className="form-group">
                <label className="form-label">New Password</label>
                <div style={{ position: 'relative' }}>
                  <input
                    type={showPass ? 'text' : 'password'} className="form-input"
                    placeholder="Min. 8 characters with a number"
                    value={newPassword} onChange={(e) => setNewPassword(e.target.value)}
                    style={{ paddingRight: 44 }} autoFocus
                  />
                  <button type="button" className="btn btn-ghost btn-icon" onClick={() => setShowPass(!showPass)}
                    style={{ position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)', padding: '4px 8px' }}>
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Confirm Password</label>
                <input
                  type="password" className="form-input" placeholder="Repeat password"
                  value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)}
                />
              </div>
              <button type="submit" className="btn btn-primary btn-lg btn-full" disabled={loading}>
                {loading ? <><div className="spinner spinner-sm" /> Resetting...</> : 'Reset Password'}
              </button>
            </form>
          </>
        )}

        {/* Step: Done */}
        {step === 'done' && (
          <div style={{ textAlign: 'center', padding: '20px 0' }}>
            <CheckCircle size={56} color="var(--accent-green)" style={{ marginBottom: 16 }} />
            <h1 className="auth-title">Password reset!</h1>
            <p className="auth-subtitle" style={{ marginBottom: 28 }}>Your password has been changed. You can now sign in with your new password.</p>
            <button className="btn btn-primary btn-lg btn-full" onClick={() => navigate('/signin')}>
              Go to Sign In
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
