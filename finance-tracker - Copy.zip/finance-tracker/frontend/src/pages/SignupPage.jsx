import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Eye, EyeOff, ArrowLeft, CheckCircle } from 'lucide-react';
import { authAPI } from '../api';
import { useAuth } from '../context/AuthContext';
import OTPInput from '../components/ui/OTPInput';

export default function SignupPage() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [step, setStep] = useState('form'); // 'form' | 'otp'
  const [userId, setUserId] = useState('');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.username.match(/^[a-zA-Z0-9_]{3,30}$/)) e.username = 'Must be 3-30 characters (letters, numbers, _)';
    if (!form.email.match(/^\S+@\S+\.\S+$/)) e.email = 'Enter a valid email';
    if (form.password.length < 8 || !/\d/.test(form.password)) e.password = 'Min 8 characters with at least one number';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const startResendTimer = () => {
    setResendTimer(60);
    const t = setInterval(() => setResendTimer((v) => { if (v <= 1) { clearInterval(t); return 0; } return v - 1; }), 1000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const { data } = await authAPI.signup(form);
      setUserId(data.data.userId);
      setEmail(form.email);
      setStep('otp');
      startResendTimer();
      toast.success('OTP sent to your email!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) return toast.error('Enter the 6-digit OTP');
    setLoading(true);
    try {
      const { data } = await authAPI.verifySignup({ userId, otp });
      login(data.data, data.data.user);
      toast.success('Account verified! Welcome 🎉');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid OTP');
      setOtp('');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    try {
      await authAPI.resendOTP({ userId, purpose: 'signup' });
      startResendTimer();
      setOtp('');
      toast.success('OTP resent!');
    } catch {
      toast.error('Failed to resend OTP');
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="auth-logo-icon">💰</div>
          <span className="auth-logo-text">FinTrack</span>
        </div>

        {step === 'form' ? (
          <>
            <h1 className="auth-title">Create account</h1>
            <p className="auth-subtitle">Track your income and expenses with ease</p>

            <form className="auth-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Username</label>
                <input
                  className={`form-input${errors.username ? ' error' : ''}`}
                  placeholder="your_username"
                  value={form.username}
                  onChange={(e) => setForm({ ...form, username: e.target.value })}
                  autoFocus
                />
                {errors.username && <span className="form-error">{errors.username}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  className={`form-input${errors.email ? ' error' : ''}`}
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                />
                {errors.email && <span className="form-error">{errors.email}</span>}
              </div>

              <div className="form-group">
                <label className="form-label">Password</label>
                <div style={{ position: 'relative' }}>
                  <input
                    type={showPass ? 'text' : 'password'}
                    className={`form-input${errors.password ? ' error' : ''}`}
                    placeholder="Min. 8 characters with a number"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    style={{ paddingRight: 44 }}
                  />
                  <button type="button" className="btn btn-ghost btn-icon" onClick={() => setShowPass(!showPass)}
                    style={{ position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)', padding: '4px 8px' }}>
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
                {errors.password && <span className="form-error">{errors.password}</span>}
              </div>

              <button type="submit" className="btn btn-primary btn-lg btn-full" disabled={loading}>
                {loading ? <><div className="spinner spinner-sm" /> Creating account...</> : 'Create Account'}
              </button>
            </form>

            <div className="auth-footer">
              Already have an account? <Link to="/signin">Sign in</Link>
            </div>
          </>
        ) : (
          <>
            <button className="btn btn-ghost btn-sm" style={{ marginBottom: 20, gap: 6, padding: '6px 0' }}
              onClick={() => { setStep('form'); setOtp(''); }}>
              <ArrowLeft size={15} /> Back
            </button>
            <h1 className="auth-title">Verify email</h1>
            <p className="auth-subtitle">
              We sent a 6-digit code to <strong style={{ color: 'var(--text-primary)' }}>{email}</strong>
            </p>

            <div style={{ margin: '28px 0' }}>
              <OTPInput value={otp} onChange={setOtp} />
            </div>

            <button className="btn btn-primary btn-lg btn-full" onClick={handleVerifyOTP} disabled={loading || otp.length !== 6}>
              {loading ? <><div className="spinner spinner-sm" /> Verifying...</> : <><CheckCircle size={16} /> Verify & Sign In</>}
            </button>

            <div className="auth-footer" style={{ marginTop: 16 }}>
              {resendTimer > 0 ? (
                <span style={{ color: 'var(--text-muted)' }}>Resend in {resendTimer}s</span>
              ) : (
                <button className="btn btn-ghost btn-sm" onClick={handleResend} style={{ color: 'var(--accent-green)' }}>
                  Resend OTP
                </button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
