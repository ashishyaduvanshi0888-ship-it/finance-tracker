import React, { useState, useEffect, useCallback } from 'react';
import { transactionAPI } from '../api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import {
  TrendingUp, TrendingDown, DollarSign, Plus, Filter,
  ChevronUp, ChevronDown, ChevronLeft, ChevronRight, Trash2, X, SlidersHorizontal
} from 'lucide-react';
import { format } from 'date-fns';

const CATEGORIES = ['General', 'Food', 'Transport', 'Housing', 'Health', 'Entertainment', 'Education', 'Shopping', 'Utilities', 'Salary', 'Freelance', 'Investment', 'Other'];

function StatCard({ title, value, icon: Icon, variant, subtitle }) {
  const colors = {
    income: { accent: 'var(--accent-green)', dim: 'var(--accent-green-dim)' },
    expense: { accent: 'var(--accent-red)', dim: 'var(--accent-red-dim)' },
    balance: { accent: 'var(--accent-blue)', dim: 'var(--accent-blue-dim)' },
  };
  const c = colors[variant];
  return (
    <div className={`stat-card ${variant}`}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
        <div>
          <div style={{ fontSize: 11, fontFamily: 'var(--font-display)', letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 4 }}>{title}</div>
          <div style={{ fontSize: 28, fontFamily: 'var(--font-display)', fontWeight: 700, color: c.accent, letterSpacing: '-1px' }}>
            ₹{Math.abs(value).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
        </div>
        <div style={{ background: c.dim, border: `1px solid ${c.accent}30`, borderRadius: 10, padding: 10 }}>
          <Icon size={20} color={c.accent} />
        </div>
      </div>
      {subtitle && <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>{subtitle}</div>}
    </div>
  );
}

function AddTransactionForm({ onAdded }) {
  const [form, setForm] = useState({ type: 'income', description: '', amount: '', category: 'General' });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.description.trim()) e.description = 'Required';
    if (!form.amount || parseFloat(form.amount) <= 0) e.amount = 'Must be > 0';
    setErrors(e);
    return !Object.keys(e).length;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    try {
      const { data } = await transactionAPI.create({ ...form, amount: parseFloat(form.amount) });
      toast.success('Transaction added!');
      setForm({ type: 'income', description: '', amount: '', category: 'General' });
      setErrors({});
      onAdded(data.data);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add transaction');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card card-padded" style={{ marginBottom: 24 }}>
      <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 700, marginBottom: 20, display: 'flex', alignItems: 'center', gap: 8 }}>
        <Plus size={18} color="var(--accent-green)" /> Add Transaction
      </h2>
      <form onSubmit={handleSubmit}>
        {/* Type toggle */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          {['income', 'expense'].map((t) => (
            <button key={t} type="button"
              onClick={() => setForm({ ...form, type: t })}
              style={{
                flex: 1, padding: '10px', borderRadius: 8, border: '1px solid',
                borderColor: form.type === t ? (t === 'income' ? 'var(--accent-green)' : 'var(--accent-red)') : 'var(--border)',
                background: form.type === t ? (t === 'income' ? 'var(--accent-green-dim)' : 'var(--accent-red-dim)') : 'transparent',
                color: form.type === t ? (t === 'income' ? 'var(--accent-green)' : 'var(--accent-red)') : 'var(--text-secondary)',
                fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 13, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                transition: 'all 0.2s',
              }}>
              {t === 'income' ? <TrendingUp size={15} /> : <TrendingDown size={15} />}
              {t.charAt(0).toUpperCase() + t.slice(1)}
            </button>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
          <div className="form-group" style={{ gridColumn: '1 / -1' }}>
            <label className="form-label">Description</label>
            <input className={`form-input${errors.description ? ' error' : ''}`}
              placeholder="e.g. Monthly salary, Grocery bill..."
              value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            {errors.description && <span className="form-error">{errors.description}</span>}
          </div>
          <div className="form-group">
            <label className="form-label">Amount (₹)</label>
            <input type="number" min="0.01" step="0.01" className={`form-input${errors.amount ? ' error' : ''}`}
              placeholder="0.00" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
            {errors.amount && <span className="form-error">{errors.amount}</span>}
          </div>
          <div className="form-group">
            <label className="form-label">Category</label>
            <select className="form-select" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <button type="submit" className="btn btn-primary btn-full" style={{ marginTop: 4 }} disabled={loading}>
          {loading ? <><div className="spinner spinner-sm" /> Adding...</> : <><Plus size={16} /> Add Transaction</>}
        </button>
      </form>
    </div>
  );
}

export default function HomePage() {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [stats, setStats] = useState({ income: 0, expense: 0, balance: 0, totalTransactions: 0 });
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [filteredSummary, setFilteredSummary] = useState({ income: 0, expense: 0, balance: 0 });
  const [loading, setLoading] = useState(true);
  const [showFilters, setShowFilters] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  const [filters, setFilters] = useState({
    type: '', startDate: '', endDate: '', minAmount: '', maxAmount: '',
    sortBy: 'date', sortOrder: 'desc', page: 1, limit: 10,
  });

  const fetchTransactions = useCallback(async () => {
    setLoading(true);
    try {
      const cleanFilters = Object.fromEntries(Object.entries(filters).filter(([, v]) => v !== ''));
      const { data } = await transactionAPI.getAll(cleanFilters);
      setTransactions(data.data.transactions);
      setPagination(data.data.pagination);
      setFilteredSummary(data.data.summary);
    } catch {
      toast.error('Failed to fetch transactions');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  const fetchStats = useCallback(async () => {
    try {
      const { data } = await transactionAPI.getStats();
      setStats(data.data.stats);
    } catch {}
  }, []);

  useEffect(() => { fetchTransactions(); }, [fetchTransactions]);
  useEffect(() => { fetchStats(); }, [fetchStats]);

  const handleTransactionAdded = (tx) => {
    fetchTransactions();
    fetchStats();
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this transaction?')) return;
    setDeletingId(id);
    try {
      await transactionAPI.delete(id);
      toast.success('Transaction deleted');
      fetchTransactions();
      fetchStats();
    } catch {
      toast.error('Failed to delete');
    } finally {
      setDeletingId(null);
    }
  };

  const setFilter = (key, val) => setFilters((f) => ({ ...f, [key]: val, page: 1 }));
  const setPage = (p) => setFilters((f) => ({ ...f, page: p }));

  const toggleSort = (field) => {
    if (filters.sortBy === field) {
      setFilters((f) => ({ ...f, sortOrder: f.sortOrder === 'asc' ? 'desc' : 'asc', page: 1 }));
    } else {
      setFilters((f) => ({ ...f, sortBy: field, sortOrder: 'desc', page: 1 }));
    }
  };

  const resetFilters = () => {
    setFilters({ type: '', startDate: '', endDate: '', minAmount: '', maxAmount: '', sortBy: 'date', sortOrder: 'desc', page: 1, limit: 10 });
  };

  const SortIcon = ({ field }) => {
    if (filters.sortBy !== field) return <span style={{ color: 'var(--text-muted)', fontSize: 10 }}>↕</span>;
    return filters.sortOrder === 'asc' ? <ChevronUp size={13} color="var(--accent-green)" /> : <ChevronDown size={13} color="var(--accent-green)" />;
  };

  const hasFilters = filters.type || filters.startDate || filters.endDate || filters.minAmount || filters.maxAmount;

  return (
    <div className="fade-in">
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, letterSpacing: '-0.5px' }}>
          Dashboard
        </h1>
        <p style={{ color: 'var(--text-secondary)', marginTop: 4, fontSize: 14 }}>
          Good to see you, <strong style={{ color: 'var(--text-primary)' }}>{user?.username}</strong> 👋
        </p>
      </div>

      {/* Stats */}
      <div className="stat-cards-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 28 }}>
        <StatCard title="Total Income" value={stats.income} icon={TrendingUp} variant="income" subtitle={`${stats.totalTransactions} total transactions`} />
        <StatCard title="Total Expenses" value={stats.expense} icon={TrendingDown} variant="expense" />
        <StatCard title="Net Balance" value={stats.balance} icon={DollarSign} variant="balance" subtitle={stats.balance >= 0 ? '✓ Positive balance' : '⚠ Negative balance'} />
      </div>

      {/* Add Transaction */}
      <AddTransactionForm onAdded={handleTransactionAdded} />

      {/* Transactions List */}
      <div className="card">
        {/* Header + Filters toggle */}
        <div style={{ padding: '20px 24px 0', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 17, fontWeight: 700 }}>Recent Transactions</h2>
            <p style={{ color: 'var(--text-muted)', fontSize: 12, marginTop: 2 }}>
              {pagination.total} transaction{pagination.total !== 1 ? 's' : ''} found
            </p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {hasFilters && (
              <button className="btn btn-sm btn-danger" onClick={resetFilters}>
                <X size={13} /> Clear
              </button>
            )}
            <button
              className={`btn btn-sm ${showFilters ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setShowFilters(!showFilters)}
            >
              <SlidersHorizontal size={14} />
              Filters {hasFilters ? `(${[filters.type, filters.startDate, filters.endDate, filters.minAmount, filters.maxAmount].filter(Boolean).length})` : ''}
            </button>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="filters-panel" style={{ margin: '16px 24px 0' }}>
            <div className="form-group">
              <label className="form-label">Type</label>
              <select className="form-select" value={filters.type} onChange={(e) => setFilter('type', e.target.value)}>
                <option value="">All</option>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">From Date</label>
              <input type="date" className="form-input" value={filters.startDate} onChange={(e) => setFilter('startDate', e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">To Date</label>
              <input type="date" className="form-input" value={filters.endDate} onChange={(e) => setFilter('endDate', e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">Min Amount</label>
              <input type="number" className="form-input" placeholder="0" value={filters.minAmount} onChange={(e) => setFilter('minAmount', e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">Max Amount</label>
              <input type="number" className="form-input" placeholder="∞" value={filters.maxAmount} onChange={(e) => setFilter('maxAmount', e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">Per Page</label>
              <select className="form-select" value={filters.limit} onChange={(e) => setFilters((f) => ({ ...f, limit: parseInt(e.target.value), page: 1 }))}>
                {[5, 10, 20, 50].map((n) => <option key={n}>{n}</option>)}
              </select>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="table-container" style={{ padding: '12px 0 0' }}>
          {loading ? (
            <div style={{ padding: '40px', display: 'flex', justifyContent: 'center' }}>
              <div className="spinner spinner-lg" />
            </div>
          ) : transactions.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">📊</div>
              <div className="empty-title">{hasFilters ? 'No matches found' : 'No transactions yet'}</div>
              <div className="empty-desc">{hasFilters ? 'Try adjusting your filters' : 'Add your first transaction above to get started'}</div>
            </div>
          ) : (
            <table>
              <thead>
                <tr>
                  <th style={{ cursor: 'pointer' }} onClick={() => toggleSort('type')}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>Type <SortIcon field="type" /></span>
                  </th>
                  <th>Description</th>
                  <th>Category</th>
                  <th style={{ cursor: 'pointer' }} onClick={() => toggleSort('amount')}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>Amount <SortIcon field="amount" /></span>
                  </th>
                  <th style={{ cursor: 'pointer' }} onClick={() => toggleSort('date')}>
                    <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>Date <SortIcon field="date" /></span>
                  </th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => (
                  <tr key={tx._id}>
                    <td><span className={`badge badge-${tx.type}`}>{tx.type === 'income' ? '↑' : '↓'} {tx.type}</span></td>
                    <td style={{ color: 'var(--text-primary)', fontWeight: 500 }}>{tx.description}</td>
                    <td style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{tx.category}</td>
                    <td style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: tx.type === 'income' ? 'var(--accent-green)' : 'var(--accent-red)' }}>
                      {tx.type === 'income' ? '+' : '-'}₹{tx.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </td>
                    <td style={{ color: 'var(--text-secondary)', fontSize: 13 }}>{format(new Date(tx.date), 'dd MMM yyyy')}</td>
                    <td>
                      <button className="btn btn-ghost btn-icon btn-sm" onClick={() => handleDelete(tx._id)}
                        disabled={deletingId === tx._id}
                        style={{ color: 'var(--text-muted)' }}
                        title="Delete">
                        {deletingId === tx._id ? <div className="spinner spinner-sm" /> : <Trash2 size={14} />}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* Filtered summary */}
        {!loading && transactions.length > 0 && (
          <div style={{ padding: '12px 24px', borderTop: '1px solid var(--border)', display: 'flex', gap: 24, flexWrap: 'wrap' }}>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
              Showing: <strong style={{ color: 'var(--accent-green)' }}>+₹{filteredSummary.income.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
              {' / '}
              <strong style={{ color: 'var(--accent-red)' }}>-₹{filteredSummary.expense.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</strong>
              {' / Net: '}
              <strong style={{ color: filteredSummary.balance >= 0 ? 'var(--accent-green)' : 'var(--accent-red)' }}>
                ₹{filteredSummary.balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </strong>
            </span>
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
            <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>
              Page {pagination.page} of {pagination.totalPages}
            </span>
            <div className="pagination">
              <button className="page-btn" onClick={() => setPage(filters.page - 1)} disabled={!pagination.hasPrev}>
                <ChevronLeft size={14} />
              </button>
              {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                const p = Math.max(1, Math.min(pagination.totalPages - 4, filters.page - 2)) + i;
                return (
                  <button key={p} className={`page-btn${filters.page === p ? ' active' : ''}`} onClick={() => setPage(p)}>
                    {p}
                  </button>
                );
              })}
              <button className="page-btn" onClick={() => setPage(filters.page + 1)} disabled={!pagination.hasNext}>
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
