import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Eye, EyeOff, CheckCircle } from 'lucide-react';
import { authAPI } from '../api';
import { useAuth } from '../context/AuthContext';
import OTPInput from '../components/ui/OTPInput';

export default function SigninPage() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [step, setStep] = useState('form'); // 'form' | 'verify'
  const [userId, setUserId] = useState('');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ email: '', password: '' });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) return toast.error('Please fill in all fields');
    setLoading(true);
    try {
      const { data } = await authAPI.signin(form);
      login(data.data, data.data.user);
      toast.success(`Welcome back, ${data.data.user.username}! 👋`);
      navigate('/');
    } catch (err) {
      const errData = err.response?.data;
      if (errData?.data?.requiresVerification) {
        setUserId(errData.data.userId);
        setEmail(form.email);
        setStep('verify');
        toast('Please verify your email first', { icon: '📧' });
      } else {
        toast.error(errData?.message || 'Sign in failed');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) return toast.error('Enter the 6-digit OTP');
    setLoading(true);
    try {
      const { data } = await authAPI.verifySignup({ userId, otp });
      login(data.data, data.data.user);
      toast.success('Email verified! Welcome 🎉');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid OTP');
      setOtp('');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="auth-logo-icon">💰</div>
          <span className="auth-logo-text">FinTrack</span>
        </div>

        {step === 'form' ? (
          <>
            <h1 className="auth-title">Welcome back</h1>
            <p className="auth-subtitle">Sign in to your account to continue</p>

            <form className="auth-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  className="form-input"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  autoFocus
                />
              </div>

              <div className="form-group">
                <label className="form-label">Password</label>
                <div style={{ position: 'relative' }}>
                  <input
                    type={showPass ? 'text' : 'password'}
                    className="form-input"
                    placeholder="Your password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    style={{ paddingRight: 44 }}
                  />
                  <button type="button" className="btn btn-ghost btn-icon" onClick={() => setShowPass(!showPass)}
                    style={{ position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)', padding: '4px 8px' }}>
                    {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <div style={{ textAlign: 'right', marginTop: -8 }}>
                <Link to="/forgot-password" style={{ color: 'var(--accent-green)', fontSize: 13, textDecoration: 'none' }}>
                  Forgot password?
                </Link>
              </div>

              <button type="submit" className="btn btn-primary btn-lg btn-full" disabled={loading}>
                {loading ? <><div className="spinner spinner-sm" /> Signing in...</> : 'Sign In'}
              </button>
            </form>

            <div className="auth-footer">
              Don't have an account? <Link to="/signup">Create one</Link>
            </div>
          </>
        ) : (
          <>
            <h1 className="auth-title">Verify email</h1>
            <p className="auth-subtitle">
              Enter the OTP sent to <strong style={{ color: 'var(--text-primary)' }}>{email}</strong>
            </p>
            <div style={{ margin: '28px 0' }}>
              <OTPInput value={otp} onChange={setOtp} />
            </div>
            <button className="btn btn-primary btn-lg btn-full" onClick={handleVerifyOTP} disabled={loading || otp.length !== 6}>
              {loading ? <><div className="spinner spinner-sm" /> Verifying...</> : <><CheckCircle size={16} /> Verify</>}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
