const User = require('../models/User.model');
const { sendOTPEmail } = require('../utils/email.util');
const { validationResult } = require('express-validator');

// @desc    Get profile
// @route   GET /api/users/me
exports.getProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    res.json({
      success: true,
      data: {
        id: user._id,
        username: user.username,
        email: user.email,
        isVerified: user.isVerified,
        lastLogin: user.lastLogin,
        createdAt: user.createdAt,
      },
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Update profile (username only)
// @route   PUT /api/users/me
exports.updateProfile = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { username } = req.body;

    if (username) {
      const existing = await User.findOne({ username, _id: { $ne: req.user.id } });
      if (existing) return res.status(409).json({ success: false, message: 'Username already taken' });
    }

    const user = await User.findByIdAndUpdate(
      req.user.id,
      { username },
      { new: true, runValidators: true }
    );

    res.json({
      success: true,
      message: 'Profile updated',
      data: { id: user._id, username: user.username, email: user.email },
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Request change password OTP
// @route   POST /api/users/change-password/request
exports.requestChangePassword = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id);
    const otp = user.generateOTP('change_password');
    await user.save();
    await sendOTPEmail(user.email, otp, 'change_password', user.username);
    res.json({ success: true, message: 'OTP sent to your registered email' });
  } catch (err) {
    next(err);
  }
};

// @desc    Verify OTP and change password
// @route   POST /api/users/change-password/verify
exports.changePassword = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { otp, currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user.id).select('+password +otp');

    const passMatch = await user.comparePassword(currentPassword);
    if (!passMatch) return res.status(401).json({ success: false, message: 'Current password is incorrect' });

    const result = await user.verifyOTP(otp, 'change_password');
    if (!result.valid) return res.status(400).json({ success: false, message: result.reason });

    user.password = newPassword;
    await user.save();

    res.json({ success: true, message: 'Password changed successfully' });
  } catch (err) {
    next(err);
  }
};
