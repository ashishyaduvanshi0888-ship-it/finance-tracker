const jwt = require('jsonwebtoken');
const User = require('../models/User.model');
const { sendOTPEmail } = require('../utils/email.util');
const { validationResult } = require('express-validator');

// Generate tokens
const generateTokens = (userId) => {
  const accessToken = jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '7d',
  });
  const refreshToken = jwt.sign({ id: userId }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRE || '30d',
  });
  return { accessToken, refreshToken };
};

// @desc    Register user & send OTP
// @route   POST /api/auth/signup
exports.signup = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { username, email, password } = req.body;

    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      const field = existingUser.email === email ? 'email' : 'username';
      return res.status(409).json({ success: false, message: `This ${field} is already registered` });
    }

    const user = await User.create({ username, email, password });
    const otp = user.generateOTP('signup');
    await user.save();

    await sendOTPEmail(email, otp, 'signup', username);

    res.status(201).json({
      success: true,
      message: 'Account created! Please verify your email with the OTP sent.',
      data: { userId: user._id, email: user.email },
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Verify signup OTP
// @route   POST /api/auth/verify-signup
exports.verifySignup = async (req, res, next) => {
  try {
    const { userId, otp } = req.body;
    const user = await User.findById(userId).select('+otp');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });
    if (user.isVerified) return res.status(400).json({ success: false, message: 'Account already verified' });

    const result = await user.verifyOTP(otp, 'signup');
    if (!result.valid) return res.status(400).json({ success: false, message: result.reason });

    user.isVerified = true;
    const { accessToken, refreshToken } = generateTokens(user._id);
    user.refreshToken = refreshToken;
    user.lastLogin = new Date();
    await user.save();

    res.json({
      success: true,
      message: 'Email verified successfully!',
      data: {
        accessToken,
        refreshToken,
        user: { id: user._id, username: user.username, email: user.email },
      },
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Resend OTP
// @route   POST /api/auth/resend-otp
exports.resendOTP = async (req, res, next) => {
  try {
    const { userId, purpose } = req.body;
    const user = await User.findById(userId).select('+otp');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    const otp = user.generateOTP(purpose);
    await user.save();
    await sendOTPEmail(user.email, otp, purpose, user.username);

    res.json({ success: true, message: 'OTP resent successfully' });
  } catch (err) {
    next(err);
  }
};

// @desc    Sign in
// @route   POST /api/auth/signin
exports.signin = async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ success: false, errors: errors.array() });
    }

    const { email, password } = req.body;
    const user = await User.findOne({ email }).select('+password +otp');
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    if (!user.isVerified) {
      const otp = user.generateOTP('signup');
      await user.save();
      await sendOTPEmail(user.email, otp, 'signup', user.username);
      return res.status(403).json({
        success: false,
        message: 'Email not verified. A new OTP has been sent.',
        data: { userId: user._id, requiresVerification: true },
      });
    }

    const { accessToken, refreshToken } = generateTokens(user._id);
    user.refreshToken = refreshToken;
    user.lastLogin = new Date();
    await user.save();

    res.json({
      success: true,
      message: 'Signed in successfully',
      data: {
        accessToken,
        refreshToken,
        user: { id: user._id, username: user.username, email: user.email },
      },
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Forgot password - send OTP
// @route   POST /api/auth/forgot-password
exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    // Always return success to prevent email enumeration
    if (!user) {
      return res.json({ success: true, message: 'If this email exists, an OTP has been sent.', data: {} });
    }

    const otp = user.generateOTP('forgot_password');
    await user.save();
    await sendOTPEmail(email, otp, 'forgot_password', user.username);

    res.json({
      success: true,
      message: 'OTP sent to your email',
      data: { userId: user._id },
    });
  } catch (err) {
    next(err);
  }
};

// @desc    Verify forgot password OTP
// @route   POST /api/auth/verify-forgot-otp
exports.verifyForgotOTP = async (req, res, next) => {
  try {
    const { userId, otp } = req.body;
    const user = await User.findById(userId).select('+otp');
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    const result = await user.verifyOTP(otp, 'forgot_password');
    if (!result.valid) return res.status(400).json({ success: false, message: result.reason });

    // Issue a short-lived reset token
    const resetToken = jwt.sign({ id: userId, purpose: 'reset' }, process.env.JWT_SECRET, { expiresIn: '15m' });
    await user.save();

    res.json({ success: true, message: 'OTP verified', data: { resetToken } });
  } catch (err) {
    next(err);
  }
};

// @desc    Reset password
// @route   POST /api/auth/reset-password
exports.resetPassword = async (req, res, next) => {
  try {
    const { resetToken, newPassword } = req.body;

    let decoded;
    try {
      decoded = jwt.verify(resetToken, process.env.JWT_SECRET);
    } catch {
      return res.status(401).json({ success: false, message: 'Invalid or expired reset token' });
    }

    if (decoded.purpose !== 'reset') {
      return res.status(401).json({ success: false, message: 'Invalid token purpose' });
    }

    const user = await User.findById(decoded.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    user.password = newPassword;
    user.refreshToken = undefined;
    await user.save();

    res.json({ success: true, message: 'Password reset successfully. Please sign in.' });
  } catch (err) {
    next(err);
  }
};

// @desc    Refresh access token
// @route   POST /api/auth/refresh
exports.refreshToken = async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ success: false, message: 'Refresh token required' });

    let decoded;
    try {
      decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    } catch {
      return res.status(401).json({ success: false, message: 'Invalid refresh token' });
    }

    const user = await User.findById(decoded.id).select('+refreshToken');
    if (!user || user.refreshToken !== refreshToken) {
      return res.status(401).json({ success: false, message: 'Invalid refresh token' });
    }

    const { accessToken, refreshToken: newRefresh } = generateTokens(user._id);
    user.refreshToken = newRefresh;
    await user.save();

    res.json({ success: true, data: { accessToken, refreshToken: newRefresh } });
  } catch (err) {
    next(err);
  }
};

// @desc    Logout
// @route   POST /api/auth/logout
exports.logout = async (req, res, next) => {
  try {
    await User.findByIdAndUpdate(req.user.id, { refreshToken: undefined });
    res.json({ success: true, message: 'Logged out successfully' });
  } catch (err) {
    next(err);
  }
};
