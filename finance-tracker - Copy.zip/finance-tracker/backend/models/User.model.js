const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, 'Username is required'],
    unique: true,
    trim: true,
    minlength: [3, 'Username must be at least 3 characters'],
    maxlength: [30, 'Username cannot exceed 30 characters'],
    match: [/^[a-zA-Z0-9_]+$/, 'Username can only contain letters, numbers, and underscores'],
  },
  email: {
    type: String,
    required: [true, 'Email is required'],
    unique: true,
    lowercase: true,
    trim: true,
    match: [/^\S+@\S+\.\S+$/, 'Please provide a valid email'],
  },
  password: {
    type: String,
    required: [true, 'Password is required'],
    minlength: [8, 'Password must be at least 8 characters'],
    select: false,
  },
  isVerified: {
    type: Boolean,
    default: false,
  },
  otp: {
    code: { type: String, select: false },
    expiresAt: { type: Date, select: false },
    purpose: { type: String, enum: ['signup', 'signin', 'forgot_password', 'change_password'], select: false },
    attempts: { type: Number, default: 0, select: false },
  },
  refreshToken: {
    type: String,
    select: false,
  },
  lastLogin: Date,
  createdAt: { type: Date, default: Date.now },
}, {
  timestamps: true,
});

// Hash password before save
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 12);
  next();
});

// Compare passwords
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

// Generate OTP
userSchema.methods.generateOTP = function (purpose) {
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  this.otp = {
    code: bcrypt.hashSync(code, 10),
    expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
    purpose,
    attempts: 0,
  };
  return code;
};

// Verify OTP
userSchema.methods.verifyOTP = async function (code, purpose) {
  if (!this.otp || !this.otp.code) return { valid: false, reason: 'No OTP found' };
  if (this.otp.purpose !== purpose) return { valid: false, reason: 'OTP purpose mismatch' };
  if (this.otp.expiresAt < new Date()) return { valid: false, reason: 'OTP expired' };
  if (this.otp.attempts >= 5) return { valid: false, reason: 'Too many attempts' };

  this.otp.attempts += 1;
  const isValid = await bcrypt.compare(code, this.otp.code);
  if (isValid) {
    this.otp = undefined;
    return { valid: true };
  }
  return { valid: false, reason: 'Invalid OTP' };
};

module.exports = mongoose.model('User', userSchema);
