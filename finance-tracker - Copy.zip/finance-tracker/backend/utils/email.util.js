const nodemailer = require('nodemailer');

const createTransporter = () => {
  return nodemailer.createTransport({
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: false,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });
};

const otpTemplates = {
  signup: (name, otp) => ({
    subject: 'Verify Your Finance Tracker Account',
    html: `
      <div style="font-family: 'Segoe UI', sans-serif; max-width: 520px; margin: 0 auto; background: #0f0f0f; color: #fff; border-radius: 16px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #00d4aa, #0099ff); padding: 32px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; letter-spacing: -1px;">💰 Finance Tracker</h1>
        </div>
        <div style="padding: 40px 32px;">
          <h2 style="color: #00d4aa; margin-top: 0;">Welcome, ${name}!</h2>
          <p style="color: #aaa; line-height: 1.6;">Use the OTP below to verify your account. It expires in <strong style="color: #fff;">10 minutes</strong>.</p>
          <div style="background: #1a1a1a; border: 2px solid #00d4aa; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0;">
            <span style="font-size: 40px; font-weight: 700; letter-spacing: 12px; color: #00d4aa; font-family: monospace;">${otp}</span>
          </div>
          <p style="color: #666; font-size: 13px;">If you didn't create this account, please ignore this email.</p>
        </div>
      </div>
    `,
  }),
  forgot_password: (name, otp) => ({
    subject: 'Reset Your Password - Finance Tracker',
    html: `
      <div style="font-family: 'Segoe UI', sans-serif; max-width: 520px; margin: 0 auto; background: #0f0f0f; color: #fff; border-radius: 16px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #ff6b6b, #ff4757); padding: 32px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; letter-spacing: -1px;">🔐 Password Reset</h1>
        </div>
        <div style="padding: 40px 32px;">
          <h2 style="color: #ff6b6b; margin-top: 0;">Hi ${name},</h2>
          <p style="color: #aaa; line-height: 1.6;">Use this OTP to reset your password. Expires in <strong style="color: #fff;">10 minutes</strong>.</p>
          <div style="background: #1a1a1a; border: 2px solid #ff6b6b; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0;">
            <span style="font-size: 40px; font-weight: 700; letter-spacing: 12px; color: #ff6b6b; font-family: monospace;">${otp}</span>
          </div>
          <p style="color: #666; font-size: 13px;">If you didn't request this, your account is safe. Ignore this email.</p>
        </div>
      </div>
    `,
  }),
  change_password: (name, otp) => ({
    subject: 'Confirm Password Change - Finance Tracker',
    html: `
      <div style="font-family: 'Segoe UI', sans-serif; max-width: 520px; margin: 0 auto; background: #0f0f0f; color: #fff; border-radius: 16px; overflow: hidden;">
        <div style="background: linear-gradient(135deg, #a29bfe, #6c5ce7); padding: 32px; text-align: center;">
          <h1 style="margin: 0; font-size: 28px; letter-spacing: -1px;">🔑 Change Password</h1>
        </div>
        <div style="padding: 40px 32px;">
          <h2 style="color: #a29bfe; margin-top: 0;">Hi ${name},</h2>
          <p style="color: #aaa; line-height: 1.6;">Use this OTP to confirm your password change. Expires in <strong style="color: #fff;">10 minutes</strong>.</p>
          <div style="background: #1a1a1a; border: 2px solid #a29bfe; border-radius: 12px; padding: 24px; text-align: center; margin: 24px 0;">
            <span style="font-size: 40px; font-weight: 700; letter-spacing: 12px; color: #a29bfe; font-family: monospace;">${otp}</span>
          </div>
        </div>
      </div>
    `,
  }),
};

exports.sendOTPEmail = async (email, otp, purpose, name = 'User') => {
  const transporter = createTransporter();
  const template = otpTemplates[purpose] || otpTemplates.signup;
  const { subject, html } = template(name, otp);

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM || 'Finance Tracker <noreply@financetracker.com>',
      to: email,
      subject,
      html,
    });
    console.log(`✉️  OTP email sent to ${email} for purpose: ${purpose}`);
  } catch (err) {
    console.error('Email send error:', err);
    // In dev, log OTP to console as fallback
    if (process.env.NODE_ENV === 'development') {
      console.log(`\n🔐 DEV OTP for ${email} [${purpose}]: ${otp}\n`);
    }
    throw new Error('Failed to send OTP email. Please try again.');
  }
};
