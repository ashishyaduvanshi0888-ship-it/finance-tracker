const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const { getProfile, updateProfile, requestChangePassword, changePassword } = require('../controllers/user.controller');
const { protect } = require('../middleware/auth.middleware');

router.use(protect);

router.get('/me', getProfile);
router.put('/me', [body('username').optional().trim().isLength({ min: 3, max: 30 }).matches(/^[a-zA-Z0-9_]+$/)], updateProfile);
router.post('/change-password/request', requestChangePassword);
router.post('/change-password/verify', [
  body('otp').isLength({ min: 6, max: 6 }),
  body('currentPassword').notEmpty(),
  body('newPassword').isLength({ min: 8 }).matches(/^(?=.*[A-Za-z])(?=.*\d)/),
], changePassword);

module.exports = router;
