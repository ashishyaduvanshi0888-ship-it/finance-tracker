const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const {
  signup, verifySignup, resendOTP, signin,
  forgotPassword, verifyForgotOTP, resetPassword,
  refreshToken, logout,
} = require('../controllers/auth.controller');
const { protect } = require('../middleware/auth.middleware');

// Validators
const signupValidator = [
  body('username').trim().isLength({ min: 3, max: 30 }).matches(/^[a-zA-Z0-9_]+$/),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }).matches(/^(?=.*[A-Za-z])(?=.*\d)/),
];

const signinValidator = [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty(),
];

router.post('/signup', signupValidator, signup);
router.post('/verify-signup', verifySignup);
router.post('/resend-otp', resendOTP);
router.post('/signin', signinValidator, signin);
router.post('/forgot-password', body('email').isEmail(), forgotPassword);
router.post('/verify-forgot-otp', verifyForgotOTP);
router.post('/reset-password', [
  body('newPassword').isLength({ min: 8 }).matches(/^(?=.*[A-Za-z])(?=.*\d)/),
], resetPassword);
router.post('/refresh', refreshToken);
router.post('/logout', protect, logout);

module.exports = router;
