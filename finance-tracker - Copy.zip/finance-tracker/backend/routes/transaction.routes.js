const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const {
  createTransaction, getTransactions, getStats,
  deleteTransaction, updateTransaction,
} = require('../controllers/transaction.controller');
const { protect } = require('../middleware/auth.middleware');

const transactionValidator = [
  body('type').isIn(['income', 'expense']),
  body('description').trim().isLength({ min: 1, max: 200 }),
  body('amount').isFloat({ min: 0.01 }),
];

router.use(protect); // all routes require auth

router.get('/stats', getStats);
router.get('/', getTransactions);
router.post('/', transactionValidator, createTransaction);
router.put('/:id', transactionValidator, updateTransaction);
router.delete('/:id', deleteTransaction);

module.exports = router;
